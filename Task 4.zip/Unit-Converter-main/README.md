# Unit-Converter
This release of the repo consists of files that can convert UNITS [temperature, currency, length, binary, weight, speed, temperature...etc], as per user's choice.


BONUS: You can also check --  present ongoing gold and silver rates in USD/INR, check currency rates of any denomination and weather of any city/country using APIs !

Hope you like this! §§

<h6 align="center">
   <img src="https://github.com/TSG405/Unit-Converter/blob/main/icon.png" alt="Here goes an ICON!">
</h6>

### @ TSG405
