#ifndef _GAME_STATE_HPP_
#define _GAME_STATE_HPP_

enum class GAMESTATE
{
    TITLE,
    MENU,
    TOWN,
    COMBAT
};

#endif // _GAME_STATE_HPP_
