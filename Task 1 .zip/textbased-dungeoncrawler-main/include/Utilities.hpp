#ifndef _UTILITIES_HPP_
#define _UTILITIES_HPP_

#include <string>

int Max(int a, int b);

int Min(int a, int b);

std::string to_lower(std::string in);
std::string to_upper(std::string in);

#endif // _UTILITIES_HPP_
