# Number-Pattern-3

This is number pyramid pattern

for example: if height=4, the pattern is:

```
   1 
  1 1 
 1 1 1 
1 1 1 1
```


You can also view other Patterns [Here](https://github.com/Annas-Furquan-Pasha?tab=repositories)
